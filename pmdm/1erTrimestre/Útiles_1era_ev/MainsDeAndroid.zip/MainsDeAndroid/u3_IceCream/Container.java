package com.rittz.icecream;

public class Container {
    String name;

    public Container(String name) {
        this.name = name;
    }

    public String toString() {
        return name;
    }
}


