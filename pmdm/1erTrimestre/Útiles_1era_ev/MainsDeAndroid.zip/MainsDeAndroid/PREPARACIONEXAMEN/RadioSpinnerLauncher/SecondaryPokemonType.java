package com.rittz.radiospinnerlauncher;

public enum SecondaryPokemonType {
    GROUND, DARK, ROCK, NORMAL, FIGHTING, FLYING, ELECTRIC, BUG, POISON, FAIRY, PSYCHIC, STEEL, ICE, GHOST, DRAGON
}
