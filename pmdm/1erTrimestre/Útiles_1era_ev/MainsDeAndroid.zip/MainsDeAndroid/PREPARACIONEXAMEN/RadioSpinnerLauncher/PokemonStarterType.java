package com.rittz.radiospinnerlauncher;

public enum PokemonStarterType {
    GRASS, FIRE, WATER
}
