package com.rittz.fragmentscharacters;

public enum GameCharacters {
    ZOMBIE, MAGE, ELF
}
