1. //cuenta[tipo = 'AHORRO']

2. //sucursal/(codigo/text() | count(cuenta[tipo = 'AHORRO']))

3. //sucursal[codigo = 'SUC3']/cuenta[tipo = 'PENSIONES']

4. //sucursal/(codigo/text() | director/text() | sum(cuenta/saldohaber))

5. //sucursal[count(cuenta) > 3]

6. //sucursal[count(cuenta[tipo = 'AHORRO']) > 3]

7. //sucursal[count(cuenta) > 3]/(director | poblacion)

8. count(//sucursal[poblacion = 'Madrid'])

9. //sucursal/(codigo/text() | sum(cuenta[tipo = 'PENSIONES']/saldohaber))

10. //cuenta[saldohaber > 10000]/(numero | nombre | saldohaber)

11. //sucursal[count(cuenta[tipo = 'AHORRO']) > 3]/(codigo/text() | sum(cuenta[tipo = 'AHORRO']/saldodebe))