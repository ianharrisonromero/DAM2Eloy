package practica2;

public class FactoriaCiclos {
    public static CicloInterface getCicloDao(){
    
        
        return new CicloBean();
    }
}
