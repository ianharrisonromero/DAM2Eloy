public class FactoriaEstudiantes {
    public static EstudianteInterface obtenerEstudianteDao() {
        return new EstudianteBean();
    }
}
